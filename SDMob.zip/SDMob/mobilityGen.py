#!/usr/bin/python3
b10 = True
b11 = True
j10 = 0
j11 = 1595

for i in range(0, 1000) :
    for k in (10, 11):
        if k == 10:
            if b10 :
                j10 = j10 + 5
                if j10 == 1600 :
                    print(k, i / 10, j10 / 100, k - 7)
                    b10 = False
                else :
                    print(k, i / 10, j10 / 100, k - 7)
            else :
                j10 = j10 - 5
                if j10 == 0 :
                    print(k, i / 10, j10 / 100, k - 7)
                    b10 = True
                else : 
                    print(k, i / 10, j10 / 100, k - 7)
        else :
            if b11 :
                j11 = j11 + 5
                if j11 == 1600 :
                    print(k, i / 10, j11 / 100, k - 8)
                    b11 = False
                else :
                    print(k, i / 10, j11 / 100, k - 8)
            else :
                j11 = j11 - 5
                if j11 == 0 :
                    print(k, i / 10, j11 / 100, k - 8)
                    b11 = True
                else : 
                    print(k, i / 10, j11 / 100, k - 8)